To jest filtr antyspamowy Sblam! dla PHP.

Instrukcje jego instalacji znajdziesz na:
http://sblam.com/instalacja.html

Jeśli używasz forum phpBB, to przeczytaj:
http://sblam.com/phpbb
albo zerknij do pliku sblambb/install.txt
